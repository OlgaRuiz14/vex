
#include "vex.h"
using namespace vex;

void avanzar(float distancia){
  Drivetrain.driveFor(forward,distancia, inches);
}
void retroceder(float distancia){
  Drivetrain.driveFor(reverse,distancia, inches);
}

void giro(float porcentaje, int lado){
  if(lado==1){
    Drivetrain.turnFor(left,porcentaje, degrees);
  }else if(lado==2){
    Drivetrain.turnFor(right, porcentaje, degrees);
  }
}

void giroRoller(float grados, int lado){
  if(lado==1){
    roller.spinFor(forward, grados, degrees);
  }else if(lado==2){
    roller.spinFor(reverse, grados, degrees);
  }
}

