
#include "vex.h"
using namespace vex;

void avanzar(float distancia){
  Drivetrain.driveFor(forward,distancia,inches);//robot maneja al frente
  }
void retroceder(float distancia){
  Drivetrain.driveFor(reverse,distancia,inches);//robot maneja atras
  }
void lado(float porcentaje, int lado){ 
  if (lado == 1){//gira el robot 
    Drivetrain.turnFor(left,porcentaje,degrees);//lado izquierdo
  }else if(lado == 2){
    Drivetrain.turnFor(right,porcentaje, degrees);//lado derecho
    }
  }
void  girobanda (float grados,int lado){ 
  if (lado==1){//giro banda arriba
    discs.spinFor(forward,grados,degrees);
  }
else if(lado==2){//giro banda abajo
    discs.spinFor(reverse,grados,degrees); 
    }
  }
void empujardiscos (float grados ,int lado){
  if (lado==1){//coloca discos al frente
     empujar.spinFor(forward,grados,degrees);
    }
  else if (lado ==2){//coloca discos atras 
    empujar.spinFor(reverse,grados,degrees);
    }
  }
void lanzardis (float grados){//lanzar dicos 
  lanzar.spinFor(reverse,grados,degrees);
  }
