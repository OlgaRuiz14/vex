/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// Drivetrain           drivetrain    1, 2, 3, 4      
// discs                motor         12              
// lanzar               motor         7               
// empujar              motor         9               
// LimitSwitchA         limit         A               
// ---- END VEXCODE CONFIGURED DEVICES ----





#include "vex.h"
#include "libreria.h"


using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  //comandos autonomo (funcion:lanzar discos)
  //posicio inicial:tercer cuadro alineado a la derecha
  //funciones en la libreria 
  retroceder(42);
  lado(40,1);
  lanzardis(300);
  lado(50,2);
  avanzar(23);




  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    int a=0;//variable para crear loop  de la banda giratoria

    //PROGRAMACION DE CONTROL*
    //commandos de control del lanzador.......................................
     if (Controller1.ButtonL2.pressing()){
       lanzar.spin(reverse);//Activar  launcher 

     }
     //la bada debe estar apagada paraa no tirar el disco
      else if (Controller1.ButtonL1.pressing()){
       empujar.setVelocity(100,percent);
       empujar.spin(reverse);//posicionar el disco (gira al frente)

     }
     else if(Controller1.ButtonR1.pressing()){
       empujar.setVelocity(100,percent);
       empujar.spin(forward);// posicionar el disco (gira atras)
      }
      
    else{
     discs.stop();
     lanzar.stop();
     empujar.stop(hold);//mantener firme  para no tirar el disco por error 
    }
    //comandos para controlar cinta transportadora............................ 
      if (Controller1.ButtonUp.pressing()){
     a=1;//comienza el loop
        }
     while(a==1) { //condicion para mantenerlo funcionando
        discs.setVelocity(100,rpm);
        discs.spin(forward);
          if (Controller1.ButtonDown.pressing()){
          a=0;//cierra loop
         }

         
              }  
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
